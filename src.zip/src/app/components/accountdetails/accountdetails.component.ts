import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-accountdetails',
  templateUrl: './accountdetails.component.html',
  styleUrls: ['./accountdetails.component.css']
})
export class AccountdetailsComponent {
requestForm!: FormGroup;
  sectors = ['Finance', 'IT', 'Healthcare', 'Education', 'Other'];
  isSidenavOpen = true;
  activeLink: string = '';
  isFormValid: boolean = false;

  constructor(private fb: FormBuilder,public router:Router,) {}

  ngOnInit(): void {
    this.requestForm = this.fb.group({
      // Customer Details
      
      EmpStatus: ['', Validators.required],
      OED: ['', Validators.required],
      Sectors: ['', Validators.required],
      IsSM: ['', Validators.required],
      AddressType: ['', Validators.required],
      Dept:['', Validators.required],
      SDept:['', Validators.required],
      SName:['', Validators.required],
      BNum:['', Validators.required],
      BName:['', Validators.required],
      Floor:['', Validators.required],
      PBox:['', Validators.required],
      PCode:['', Validators.required],
      TLName:['', Validators.required],
      DistName:['', Validators.required],
      CBDiv:['', Validators.required],
      Country:['', Validators.required],
      AL1: ['', Validators.required],
      AL2: ['', Validators.required],
      AL3: ['', Validators.required],

      // Address
      streetName: [''],
      postcode: [''],
      townLocationName: [''],

      // Employment Details
      employmentStatus: ['', Validators.required],
      sectors: [''],

      // Account Details
      accountName: ['', Validators.required],
      accountNumber: ['', Validators.required],
      currency: ['', Validators.required],
    });
    this.requestForm.statusChanges.subscribe(status => {
      this.isFormValid = status === 'VALID';
    })
    window.addEventListener('DOMContentLoaded', function() {
      const currentPage = window.location.pathname;
      const sidenavItems = document.querySelectorAll('.centered-btn');
      sidenavItems.forEach(item => {
        const link = item.querySelector('a');
        if (link && link.getAttribute('href') === currentPage) {
          item.classList.add('active');
        } else {
          item.classList.remove('active');
        }
      });
    });


  }

  setActiveClass(link: string) {
    this.activeLink = link;
  }
  
  onSubmit(): void {
    if (this.requestForm.valid) {
      console.log('Form Submitted', this.requestForm.value);
    }
  }

  onCancel(): void {
    this.requestForm.reset();
  }

  onSearch(event: any): void {
    const query = event.target.value;
    console.log('Search query:', query);
  }

  // Method for profile action
  onProfile(): void {
    console.log('Navigating to profile');
  }

  // Method for logout action
  onLogout(): void {
    this.router.navigate(['']);
  }
  NavtoPayDetails():void{
    this.router.navigate(['/paymentdetails']);
  }
 
}
