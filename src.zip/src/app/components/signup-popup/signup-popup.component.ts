import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { MatDialogRef } from '@angular/material/dialog';
import { DatePipe } from '@angular/common';
import { NgForm } from '@angular/forms';

@Component({
  standalone: false,
  selector: 'app-signup-popup',
  templateUrl: './signup-popup.component.html',
  providers: [DatePipe]
})
export class SignupPopupComponent {
  username = '';
  firstName = '';
  lastName='';
  password = '';
  name='';
  dob:Date= new Date();


  constructor(
    private authService: AuthService,
    private dialogRef: MatDialogRef<SignupPopupComponent>,
    public router:Router,
    private datePipe: DatePipe
  ) {}

  signup(signupForm:NgForm) {
  
    console.log(signupForm.value.dob);

    const formattedDob = this.datePipe.transform(this.dob, 'yyyy-MM-dd');
    signupForm.value.dob=formattedDob;
       console.log('Formatted Date of Birth:', formattedDob);
     if (signupForm.value.firstName && signupForm.value.username && signupForm.value.password && signupForm.value.lastName && signupForm.value.dob) {
       this.authService.registerUser(signupForm.value.firstName, signupForm.value.lastName,signupForm.value.dob,signupForm.value.username, signupForm.value.password);
       //alert('Signup successful!');
       
       this.router.navigate(['/signup',signupForm.value.username,signupForm.value.firstName,signupForm.value.lastName,signupForm.value.dob]);
       this.dialogRef.close();
     } else {
       alert('Please fill out all fields.');
     }
   }
  }
